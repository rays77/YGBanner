//
//  YGBanner.h
//  UIScrollView循环滚动_1
//
//  Created by wuyiguang on 15/9/6.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#import <UIKit/UIKit.h>

// scrollView滚动的间隔时间
#define kIntervalTime 3.0

typedef void(^ImageHandle)(NSInteger index);

@interface YGBanner : UIView

@property (nonatomic, copy) ImageHandle block;

/**
 *  实例化轮播视图
 *
 *  @param frame banner的frame
 *  @param names 图片的名字
 *  @param block 点击图片时的block回调
 *
 *  @return 返回Banner
 */
- (instancetype)initWithFrame:(CGRect)frame imageNames:(NSArray *)names imageHandle:(ImageHandle)block;

@end
