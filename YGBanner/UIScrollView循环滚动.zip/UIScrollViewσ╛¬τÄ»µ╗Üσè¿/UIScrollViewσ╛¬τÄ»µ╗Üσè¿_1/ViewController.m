//
//  ViewController.m
//  UIScrollView循环滚动_1
//
//  Created by wuyiguang on 15/9/6.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#import "ViewController.h"
#import "YGBanner.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 实例YGBanner代码
    
    NSArray *imageNames = @[@"1.jpg", @"2.jpg", @"3.jpg", @"4.jpg"];
    
    YGBanner *banner = [[YGBanner alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 160) imageNames:imageNames imageHandle:^(NSInteger index) {
        
        NSLog(@"点击了YGBanner第%ld张图", index);
    }];
    
    [self.view addSubview:banner];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
