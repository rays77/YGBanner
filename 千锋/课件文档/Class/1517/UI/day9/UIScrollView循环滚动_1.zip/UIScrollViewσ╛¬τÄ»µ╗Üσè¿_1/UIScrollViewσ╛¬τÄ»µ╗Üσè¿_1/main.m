//
//  main.m
//  UIScrollView循环滚动_1
//
//  Created by wuyiguang on 15/9/6.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
